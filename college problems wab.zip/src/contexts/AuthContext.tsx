import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import supabase from '../lib/supabase';

export interface User {
  id: string;
  email?: string;
  phone?: string;
  role?: string;
  full_name?: string;
  token?: string;
}

export interface Profile {
  id: string;
  email: string;
  full_name: string;
  dob: string;
  gender: string;
  address: string;
  phone: string;
  id_number: string;
  course_of_interest: string;
  last_school: string;
  marks_percentage: number | null;
  role: string;
  updated_at: string;
}

interface AuthContextType {
  user: User | null;
  profile: Profile | null;
  loading: boolean;
  loginWithEmail: (email: string, password: string) => Promise<any>;
  signupWithEmail: (email: string, password: string) => Promise<any>;
  loginWithPhoneSession: (phoneUser: User) => void;
  logout: () => Promise<void>;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  profile: null,
  loading: true,
  loginWithEmail: async () => {},
  signupWithEmail: async () => {},
  loginWithPhoneSession: () => {},
  logout: async () => {},
  refreshProfile: async () => {}
});

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);

  // Helper to fetch profile from API
  const fetchProfile = async (userId: string, token: string | null = null) => {
    try {
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      } else {
        headers['X-User-Id'] = userId;
      }

      const res = await fetch('/api/profile', { headers });
      if (res.ok) {
        const data = await res.json();
        return data;
      }
    } catch (err) {
      console.error('Error fetching profile from API:', err);
    }
    return null;
  };

  const refreshProfile = async () => {
    if (!user) return;
    const session = await supabase.auth.getSession();
    const token = session.data.session?.access_token || null;
    const p = await fetchProfile(user.id, token);
    setProfile(p);
  };

  useEffect(() => {
    // 1. Check if there's a custom phone user session in localStorage
    const savedPhoneUser = localStorage.getItem('smart_admission_phone_user');
    if (savedPhoneUser) {
      try {
        const parsed = JSON.parse(savedPhoneUser);
        setUser(parsed);
        fetchProfile(parsed.id).then(p => {
          setProfile(p);
          setLoading(false);
        });
        return;
      } catch (e) {
        localStorage.removeItem('smart_admission_phone_user');
      }
    }

    // 2. Otherwise, check standard Supabase Session
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session?.user) {
        const mappedUser: User = {
          id: session.user.id,
          email: session.user.email,
          token: session.access_token
        };
        setUser(mappedUser);
        fetchProfile(session.user.id, session.access_token).then(p => {
          setProfile(p);
          setLoading(false);
        });
      } else {
        setUser(null);
        setProfile(null);
        setLoading(false);
      }
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (_event, session) => {
      // If we have a phone session saved, don't override unless Supabase session actually starts
      if (localStorage.getItem('smart_admission_phone_user') && !session?.user) {
        return;
      }

      if (session?.user) {
        const mappedUser: User = {
          id: session.user.id,
          email: session.user.email,
          token: session.access_token
        };
        setUser(mappedUser);
        const p = await fetchProfile(session.user.id, session.access_token);
        setProfile(p);
      } else {
        setUser(null);
        setProfile(null);
      }
      setLoading(false);
    });

    return () => subscription.unsubscribe();
  }, []);

  const loginWithEmail = async (email: string, password: string) => {
    setLoading(true);
    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) {
      setLoading(false);
      throw error;
    }
    return data;
  };

  const signupWithEmail = async (email: string, password: string) => {
    setLoading(true);
    const { data, error } = await supabase.auth.signUp({ email, password });
    if (error) {
      setLoading(false);
      throw error;
    }
    return data;
  };

  const loginWithPhoneSession = (phoneUser: User) => {
    setLoading(true);
    localStorage.setItem('smart_admission_phone_user', JSON.stringify(phoneUser));
    setUser(phoneUser);
    fetchProfile(phoneUser.id).then(p => {
      setProfile(p);
      setLoading(false);
    });
  };

  const logout = async () => {
    setLoading(true);
    localStorage.removeItem('smart_admission_phone_user');
    await supabase.auth.signOut();
    setUser(null);
    setProfile(null);
    setLoading(false);
  };

  return (
    <AuthContext.Provider value={{
      user,
      profile,
      loading,
      loginWithEmail,
      signupWithEmail,
      loginWithPhoneSession,
      logout,
      refreshProfile
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
