import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { GraduationCap, LogOut, User, LayoutDashboard, FileText, ClipboardList } from 'lucide-react';

export default function Navbar() {
  const { user, profile, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  return (
    <nav className="bg-slate-900 text-white shadow-md border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2">
            <div className="bg-teal-500 p-2 rounded-lg">
              <GraduationCap className="w-6 h-6 text-slate-950" />
            </div>
            <div>
              <span className="font-bold text-lg tracking-tight block">EduSmart</span>
              <span className="text-xs text-slate-400 block -mt-1">Admission & Autofill Portal</span>
            </div>
          </Link>

          {/* Nav Items */}
          {user && (
            <div className="flex items-center space-x-4">
              {profile?.role === 'staff' ? (
                <Link
                  to="/staff-dashboard"
                  className="flex items-center space-x-1 text-sm font-medium text-teal-400 hover:text-teal-300 transition-colors"
                >
                  <ClipboardList className="w-4 h-4" />
                  <span>Staff Panel</span>
                </Link>
              ) : (
                <>
                  <Link
                    to="/dashboard"
                    className="flex items-center space-x-1 text-sm font-medium text-slate-300 hover:text-white transition-colors"
                  >
                    <LayoutDashboard className="w-4 h-4" />
                    <span>Dashboard</span>
                  </Link>
                  <Link
                    to="/profile-setup"
                    className="flex items-center space-x-1 text-sm font-medium text-slate-300 hover:text-white transition-colors"
                  >
                    <User className="w-4 h-4" />
                    <span>My Profile</span>
                  </Link>
                </>
              )}

              {/* User Info & Logout */}
              <div className="h-6 w-px bg-slate-700 hidden sm:block"></div>

              <div className="flex items-center space-x-3">
                <div className="hidden md:block text-right">
                  <div className="text-sm font-semibold text-slate-200">
                    {profile?.full_name || user.email || 'Student'}
                  </div>
                  <div className="text-xs text-slate-400 capitalize">
                    {profile?.role || 'Student'}
                  </div>
                </div>

                <button
                  onClick={handleLogout}
                  className="bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white p-2 rounded-full transition-colors flex items-center justify-center"
                  title="Logout"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
}
