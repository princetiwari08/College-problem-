import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { createWorker } from 'tesseract.js';
import { Scan, FileText, Upload, AlertCircle, Save, CheckCircle, User, Award, BookOpen } from 'lucide-react';

export default function ProfileSetup() {
  const { user, profile, refreshProfile } = useAuth();
  const navigate = useNavigate();

  // Profile Form States
  const [fullName, setFullName] = useState('');
  const [dob, setDob] = useState('');
  const [gender, setGender] = useState('');
  const [address, setAddress] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [idNumber, setIdNumber] = useState('');
  const [courseOfInterest, setCourseOfInterest] = useState('');
  const [lastSchool, setLastSchool] = useState('');
  const [marksPercentage, setMarksPercentage] = useState('');

  // OCR/Scanning States
  const [ocrLoading, setOcrLoading] = useState(false);
  const [ocrProgress, setOcrProgress] = useState(0);
  const [ocrStatusText, setOcrStatusText] = useState('');
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [ocrExtractedText, setOcrExtractedText] = useState('');
  const [ocrError, setOcrError] = useState('');

  // Form Submit States
  const [saving, setSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [formError, setFormError] = useState('');

  // Load existing profile details
  useEffect(() => {
    if (profile) {
      setFullName(profile.full_name || '');
      setDob(profile.dob || '');
      setGender(profile.gender || '');
      setAddress(profile.address || '');
      setPhone(profile.phone || '');
      setEmail(profile.email || user?.email || '');
      setIdNumber(profile.id_number || '');
      setCourseOfInterest(profile.course_of_interest || '');
      setLastSchool(profile.last_school || '');
      setMarksPercentage(profile.marks_percentage ? profile.marks_percentage.toString() : '');
    }
  }, [profile, user]);

  // OCR Handler (Client-side Tesseract.js)
  const handleOcrUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Set image preview
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setImagePreview(reader.result);
      }
    };
    reader.readAsDataURL(file);

    setOcrLoading(true);
    setOcrProgress(0);
    setOcrStatusText('Initializing OCR Engine...');
    setOcrError('');
    setOcrExtractedText('');

    try {
      const worker = await createWorker('eng');
      
      setOcrStatusText('Scanning document pixels...');
      setOcrProgress(30);

      const ret = await worker.recognize(file);
      const text = ret.data.text;
      
      setOcrProgress(80);
      setOcrStatusText('Analyzing extracted text...');
      setOcrExtractedText(text);

      // Perform Regex pattern matching to extract fields
      parseOcrText(text);

      await worker.terminate();
      setOcrProgress(100);
      setOcrStatusText('OCR Complete!');
    } catch (err) {
      console.error('OCR Error:', err);
      setOcrError('Failed to parse text from the uploaded document. Please complete the form manually.');
    } finally {
      setOcrLoading(false);
    }
  };

  // Extract profiles fields using regex patterns
  const parseOcrText = (text: string) => {
    let extractedName = '';
    let extractedDob = '';
    let extractedId = '';
    let extractedMarks = '';

    text.split('\n').forEach(line => {
      const lower = line.toLowerCase();
      
      // 1. Name Match
      if (lower.includes('name') || lower.includes('full name') || lower.includes('student name')) {
        const match = line.match(/(?:name|full name|student name)\s*[:\-]\s*(.*)/i);
        if (match && match[1]) extractedName = match[1].trim();
      }

      // 2. DOB Match
      if (lower.includes('dob') || lower.includes('birth') || lower.includes('date of birth')) {
        const match = line.match(/(?:dob|birth|date of birth)\s*[:\-]\s*([\w\/\-\s,]+)/i);
        if (match && match[1]) {
          const dateStr = match[1].trim();
          extractedDob = formatDateString(dateStr);
        }
      }

      // 3. ID/Aadhar Match
      if (lower.includes('aadhar') || lower.includes('id no') || lower.includes('id number') || lower.includes('card number')) {
        const match = line.match(/(?:aadhar|id no|id number|card number)\s*[:\-]?\s*([\w\s\-]{8,16})/i);
        if (match && match[1]) extractedId = match[1].trim();
      }

      // 4. Marks/Percentage Match
      if (lower.includes('marks') || lower.includes('percentage') || lower.includes('gpa') || lower.includes('score')) {
        const match = line.match(/(?:percentage|marks|gpa|score)\s*[:\-]?\s*([0-9\.]+)\s*%?/i);
        if (match && match[1]) extractedMarks = match[1].trim();
      }
    });

    // Fallbacks if no key-value pattern matches but specific formats are found
    if (!extractedDob) {
      const dateRegex = /(\d{2}[\/\-]\d{2}[\/\-]\d{4})|(\d{4}[\/\-]\d{2}[\/\-]\d{2})/;
      const match = text.match(dateRegex);
      if (match) extractedDob = formatDateString(match[0]);
    }

    if (!extractedId) {
      const aadharRegex = /\b\d{4}\s\d{4}\s\d{4}\b|\b\d{12}\b/;
      const match = text.match(aadharRegex);
      if (match) extractedId = match[0];
    }

    if (!extractedMarks) {
      const pctRegex = /(\d{2}(?:\.\d{1,2})?)\s*%/;
      const match = text.match(pctRegex);
      if (match && match[1]) extractedMarks = match[1];
    }

    // Update States if fields were successfully extracted
    if (extractedName) setFullName(extractedName);
    if (extractedDob) setDob(extractedDob);
    if (extractedId) setIdNumber(extractedId);
    if (extractedMarks) setMarksPercentage(extractedMarks);
  };

  const formatDateString = (str: string) => {
    const parts = str.split(/[\/\-]/);
    if (parts.length === 3) {
      if (parts[2].length === 4) {
        // DD/MM/YYYY
        return `${parts[2]}-${parts[1].padStart(2, '0')}-${parts[0].padStart(2, '0')}`;
      } else if (parts[0].length === 4) {
        // YYYY-MM-DD
        return `${parts[0]}-${parts[1].padStart(2, '0')}-${parts[2].padStart(2, '0')}`;
      }
    }
    return str;
  };

  const handleSubmitProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setSaving(true);
    setFormError('');
    setSaveSuccess(false);

    try {
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (user.token) {
        headers['Authorization'] = `Bearer ${user.token}`;
      } else if (user.id) {
        headers['X-User-Id'] = user.id;
      }

      const res = await fetch('/api/profile', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          email,
          full_name: fullName,
          dob,
          gender,
          address,
          phone,
          id_number: idNumber,
          course_of_interest: courseOfInterest,
          last_school: lastSchool,
          marks_percentage: marksPercentage
        })
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to save profile');

      await refreshProfile(); // Refresh AuthContext profile
      setSaveSuccess(true);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (err: any) {
      setFormError(err.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 pb-16">
      {/* Header */}
      <div className="bg-slate-900 text-white py-12 px-4 sm:px-6 lg:px-8 border-b border-slate-800">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">One-Time Master Profile Setup</h1>
            <p className="text-slate-400 mt-2 text-sm max-w-xl">
              Fill out your details below. You can use the AI OCR scanner to upload your ID card or marksheet to instantly pre-fill fields!
            </p>
          </div>
          <button
            onClick={() => navigate('/dashboard')}
            className="text-xs bg-slate-800 border border-slate-700 hover:bg-slate-700 px-4 py-2 rounded-xl text-slate-300 font-semibold self-start md:self-center transition-colors"
          >
            ← Back to Dashboard
          </button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-10">
        {saveSuccess && (
          <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-5 mb-8 flex items-center space-x-4 shadow-sm animate-fade-in">
            <CheckCircle className="w-8 h-8 text-emerald-600 shrink-0" />
            <div>
              <h3 className="font-bold text-emerald-900 text-base">Master Profile Saved Successfully!</h3>
              <p className="text-sm text-emerald-700 mt-0.5">
                Your credentials are now permanently stored in the database. Any form you open on this portal will automatically auto-fill with these details.
              </p>
            </div>
          </div>
        )}

        {formError && (
          <div className="bg-rose-50 border border-rose-200 rounded-2xl p-5 mb-8 flex items-center space-x-4 shadow-sm">
            <AlertCircle className="w-8 h-8 text-rose-600 shrink-0" />
            <div>
              <h3 className="font-bold text-rose-900 text-base">Failed to Save Profile</h3>
              <p className="text-sm text-rose-700 mt-0.5">{formError}</p>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* LEFT PANEL: OCR SCANNER (cols: 5) */}
          <div className="lg:col-span-5 space-y-6">
            <div className="bg-white border border-slate-200 rounded-2xl shadow-sm p-6 overflow-hidden relative">
              <div className="flex items-center space-x-2 border-b border-slate-100 pb-4 mb-4">
                <Scan className="w-5 h-5 text-teal-600 animate-pulse" />
                <h3 className="font-bold text-slate-900 text-base">Smart AI OCR Scanner</h3>
              </div>

              <p className="text-xs text-slate-500 leading-relaxed mb-4">
                Upload a clear picture of your ID card, Aadhar Card, or academic marksheet. Our OCR engine will scan the text and pre-populate your profile fields.
              </p>

              {/* Upload Dropzone */}
              <div className="border-2 border-dashed border-slate-200 hover:border-teal-500 rounded-2xl p-6 text-center transition-all bg-slate-50/50 relative group">
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleOcrUpload}
                  disabled={ocrLoading}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                />
                <div className="space-y-3">
                  <div className="w-12 h-12 bg-white border border-slate-200 rounded-full flex items-center justify-center text-slate-400 group-hover:text-teal-600 group-hover:border-teal-200 transition-colors mx-auto shadow-sm">
                    <Upload className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-slate-800">Upload Marksheet or ID Card</p>
                    <p className="text-xs text-slate-400 mt-1">Supports PNG, JPG, JPEG up to 5MB</p>
                  </div>
                </div>
              </div>

              {/* OCR Scanning Progress / Animation */}
              {ocrLoading && (
                <div className="mt-6 border border-teal-100 bg-teal-50/20 rounded-2xl p-5 space-y-3 animate-pulse">
                  <div className="flex justify-between text-xs font-bold text-teal-700">
                    <span>{ocrStatusText}</span>
                    <span>{ocrProgress}%</span>
                  </div>
                  <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                    <div
                      className="bg-teal-500 h-full transition-all duration-300"
                      style={{ width: `${ocrProgress}%` }}
                    ></div>
                  </div>
                  <p className="text-[10px] text-slate-400">Processing locally in-browser for complete privacy.</p>
                </div>
              )}

              {/* Image Preview & Scanner Visualizer */}
              {imagePreview && (
                <div className="mt-6 space-y-4">
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Document Preview</h4>
                  <div className="relative border border-slate-200 rounded-xl overflow-hidden aspect-video bg-slate-950 flex items-center justify-center">
                    <img src={imagePreview} alt="Uploaded Document" className="max-h-full object-contain" />
                    {/* Visual scanner line */}
                    {ocrLoading && (
                      <div className="absolute left-0 right-0 h-1 bg-teal-400 shadow-[0_0_15px_#2dd4bf] animate-[scan_2s_infinite]"></div>
                    )}
                  </div>
                </div>
              )}

              {/* OCR Extracted Text Preview (Collapsed) */}
              {ocrExtractedText && !ocrLoading && (
                <div className="mt-6 space-y-2">
                  <div className="flex justify-between items-center">
                    <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Extracted Text Preview</h4>
                    <span className="text-[10px] text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-100 font-bold">Successfully Parsed</span>
                  </div>
                  <pre className="text-xs bg-slate-950 text-emerald-400 p-4 rounded-xl max-h-36 overflow-y-auto font-mono whitespace-pre-wrap border border-slate-800">
                    {ocrExtractedText}
                  </pre>
                </div>
              )}

              {ocrError && (
                <div className="mt-6 bg-rose-50 border border-rose-100 rounded-2xl p-4 flex items-start space-x-3 text-rose-700 text-xs">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <p>{ocrError}</p>
                </div>
              )}
            </div>

            {/* Privacy note */}
            <div className="bg-slate-900 text-slate-400 rounded-2xl p-5 border border-slate-800 space-y-2 text-xs">
              <h4 className="font-semibold text-white">🔒 In-Browser Privacy Guard</h4>
              <p className="leading-relaxed">
                Our OCR scanner processes images entirely on your local machine using client-side WebAssembly (Tesseract.js). Your documents are never uploaded to foreign servers, ensuring 100% compliance with data privacy regulations.
              </p>
            </div>
          </div>

          {/* RIGHT PANEL: MASTER PROFILE FORM (cols: 7) */}
          <form onSubmit={handleSubmitProfile} className="lg:col-span-7 bg-white border border-slate-200 rounded-2xl shadow-sm p-6 sm:p-8 space-y-6">
            <div className="flex items-center space-x-2 border-b border-slate-100 pb-4 mb-4">
              <FileText className="w-5 h-5 text-teal-600" />
              <h3 className="font-bold text-slate-900 text-base">Master Profile Details</h3>
            </div>

            {/* Section 1: Personal Details */}
            <div className="space-y-4">
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center space-x-1">
                <User className="w-3.5 h-3.5 text-teal-600" />
                <span>Personal Information</span>
              </h4>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Full Name *</label>
                  <input
                    type="text"
                    required
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="block w-full px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500"
                    placeholder="Alex Johnson"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Date of Birth *</label>
                  <input
                    type="date"
                    required
                    value={dob}
                    onChange={(e) => setDob(e.target.value)}
                    className="block w-full px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Gender *</label>
                  <select
                    required
                    value={gender}
                    onChange={(e) => setGender(e.target.value)}
                    className="block w-full px-3.5 py-2 border border-slate-200 rounded-xl text-sm bg-white focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500"
                  >
                    <option value="">Select Gender</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Non-binary">Non-binary</option>
                    <option value="Other">Other</option>
                    <option value="Prefer not to say">Prefer not to say</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Aadhar / ID Number *</label>
                  <input
                    type="text"
                    required
                    value={idNumber}
                    onChange={(e) => setIdNumber(e.target.value)}
                    className="block w-full px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500"
                    placeholder="ID-987654321"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-500 mb-1">Residential Address *</label>
                <textarea
                  required
                  rows={2}
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="block w-full px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500"
                  placeholder="123 University Ave, Boston, MA"
                ></textarea>
              </div>
            </div>

            {/* Section 2: Contact Information */}
            <div className="space-y-4 pt-4 border-t border-slate-100">
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center space-x-1">
                <AlertCircle className="w-3.5 h-3.5 text-teal-600" />
                <span>Contact Details</span>
              </h4>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Phone Number *</label>
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="block w-full px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500"
                    placeholder="+15550188"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Email Address *</label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="block w-full px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500"
                    placeholder="student@example.com"
                  />
                </div>
              </div>
            </div>

            {/* Section 3: Academic Details */}
            <div className="space-y-4 pt-4 border-t border-slate-100">
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center space-x-1">
                <Award className="w-3.5 h-3.5 text-teal-600" />
                <span>Academic & Course Interest</span>
              </h4>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Course of Interest *</label>
                  <select
                    required
                    value={courseOfInterest}
                    onChange={(e) => setCourseOfInterest(e.target.value)}
                    className="block w-full px-3.5 py-2 border border-slate-200 rounded-xl text-sm bg-white focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500"
                  >
                    <option value="">Select Course</option>
                    <option value="Computer Science">Computer Science (B.Sc)</option>
                    <option value="Information Technology">Information Technology (B.Tech)</option>
                    <option value="Business Administration">Business Administration (BBA)</option>
                    <option value="Data Science">Data Science (M.Sc)</option>
                    <option value="Electrical Engineering">Electrical Engineering (B.E)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Last School/College Attended *</label>
                  <input
                    type="text"
                    required
                    value={lastSchool}
                    onChange={(e) => setLastSchool(e.target.value)}
                    className="block w-full px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500"
                    placeholder="Boston High School"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Marks / Percentage (%) *</label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    max="100"
                    required
                    value={marksPercentage}
                    onChange={(e) => setMarksPercentage(e.target.value)}
                    className="block w-full px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500"
                    placeholder="88.50"
                  />
                </div>
              </div>
            </div>

            {/* Submit Button */}
            <div className="pt-4 border-t border-slate-100 flex items-center justify-end space-x-3">
              <button
                type="button"
                onClick={() => navigate('/dashboard')}
                className="px-5 py-2.5 border border-slate-200 hover:bg-slate-50 text-slate-600 font-semibold rounded-xl text-sm transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={saving}
                className="px-6 py-2.5 bg-teal-500 hover:bg-teal-400 disabled:bg-teal-300 text-slate-950 font-bold rounded-xl text-sm shadow-sm transition-colors flex items-center space-x-1.5"
              >
                {saving ? (
                  <div className="w-5 h-5 border-2 border-slate-950 border-t-transparent rounded-full animate-spin"></div>
                ) : (
                  <>
                    <Save className="w-4 h-4" />
                    <span>Save Master Profile</span>
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
