import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { signInWithGoogle } from '../lib/googleAuth';
import { GraduationCap, Mail, Lock, Phone, ArrowRight, CheckCircle2, ShieldCheck } from 'lucide-react';

export default function Login() {
  const { loginWithEmail, signupWithEmail, loginWithPhoneSession } = useAuth();
  const navigate = useNavigate();

  const [activeTab, setActiveTab] = useState('email'); // 'email' or 'phone'
  const [isSignUp, setIsSignUp] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  // Email state
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [accessCode, setAccessCode] = useState(''); // STAFF2025 for staff role

  // Phone state
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [demoOtp, setDemoOtp] = useState('');

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      if (isSignUp) {
        // Register in Supabase Auth
        const signUpResult = await signupWithEmail(email, password);
        const userId = signUpResult?.user?.id;

        if (userId) {
          // Send profile record with role based on accessCode
          const headers: Record<string, string> = { 'Content-Type': 'application/json' };
          headers['X-User-Id'] = userId;

          await fetch('/api/profile', {
            method: 'POST',
            headers,
            body: JSON.stringify({
              email,
              full_name: 'New Student',
              accessCode: accessCode.trim()
            })
          });
        }
        setIsSignUp(false);
        setError('Account created successfully! Please log in.');
      } else {
        // Login in Supabase Auth
        await loginWithEmail(email, password);
        navigate('/');
      }
    } catch (err: any) {
      console.error('Email Auth Error:', err);
      setError(err.message || 'An error occurred during authentication.');
    } finally {
      setLoading(false);
    }
  };

  const handleSendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!phone) return setError('Please enter a phone number');

    setLoading(true);
    try {
      const res = await fetch('/api/auth/phone-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'send-otp', phone })
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to send OTP');

      setOtpSent(true);
      setDemoOtp(data.otp); // Show the OTP on screen for demo purposes
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!otp) return setError('Please enter the 6-digit OTP');

    setLoading(true);
    try {
      const res = await fetch('/api/auth/phone-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'verify-otp', phone, otp })
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to verify OTP');

      // Login using custom phone session
      loginWithPhoneSession(data.user);

      if (data.user.role === 'staff') {
        navigate('/staff-dashboard');
      } else {
        navigate('/dashboard');
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 flex flex-col justify-center py-12 sm:px-6 lg:px-8 relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-teal-500/10 rounded-full blur-3xl -z-10"></div>
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl -z-10"></div>

      <div className="sm:mx-auto sm:w-full sm:max-w-md text-center">
        <div className="inline-flex items-center justify-center p-3 bg-teal-500 rounded-2xl shadow-lg shadow-teal-500/20 mb-4">
          <GraduationCap className="w-10 h-10 text-slate-950" />
        </div>
        <h2 className="text-3xl font-extrabold text-white tracking-tight">
          EduSmart Admission Portal
        </h2>
        <p className="mt-2 text-sm text-slate-400">
          Centralized Student Profile & Auto-Fill System
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-slate-800/80 backdrop-blur-md py-8 px-4 shadow-2xl border border-slate-700/50 sm:rounded-2xl sm:px-10">
          {/* Tab Selection */}
          <div className="flex border-b border-slate-700 pb-4 mb-6">
            <button
              onClick={() => {
                setActiveTab('email');
                setError('');
              }}
              className={`flex-1 text-center pb-2 text-sm font-semibold border-b-2 transition-all ${
                activeTab === 'email'
                  ? 'border-teal-400 text-teal-400'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              Email Sign In
            </button>
            <button
              onClick={() => {
                setActiveTab('phone');
                setError('');
              }}
              className={`flex-1 text-center pb-2 text-sm font-semibold border-b-2 transition-all ${
                activeTab === 'phone'
                  ? 'border-teal-400 text-teal-400'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              Phone + OTP Login
            </button>
          </div>

          {error && (
            <div className={`p-3 rounded-lg mb-4 text-sm ${
              error.includes('successfully') || error.includes('created')
                ? 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-400' 
                : 'bg-rose-500/10 border border-rose-500/30 text-rose-400'
            }`}>
              {error}
            </div>
          )}

          {/* EMAIL FORM */}
          {activeTab === 'email' && (
            <form onSubmit={handleEmailAuth} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider">
                  Email Address
                </label>
                <div className="mt-1 relative rounded-md shadow-sm">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Mail className="h-4 w-4 text-slate-400" />
                  </div>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="block w-full pl-10 pr-3 py-2 bg-slate-950/50 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-transparent text-sm"
                    placeholder="student@example.com"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider">
                  Password
                </label>
                <div className="mt-1 relative rounded-md shadow-sm">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Lock className="h-4 w-4 text-slate-400" />
                  </div>
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="block w-full pl-10 pr-3 py-2 bg-slate-950/50 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-transparent text-sm"
                    placeholder="••••••••"
                  />
                </div>
              </div>

              {isSignUp && (
                <div className="border border-teal-500/20 bg-teal-500/5 p-3 rounded-lg space-y-2">
                  <div className="flex items-center space-x-1.5 text-teal-400 text-xs font-bold">
                    <ShieldCheck className="w-4 h-4" />
                    <span>Staff Promotion Code (Optional)</span>
                  </div>
                  <input
                    type="text"
                    value={accessCode}
                    onChange={(e) => setAccessCode(e.target.value)}
                    className="block w-full px-3 py-1.5 bg-slate-950 border border-slate-700 rounded-md text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-teal-500 text-xs"
                    placeholder="Enter STAFF2025 for staff panel"
                  />
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full py-2.5 px-4 bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500 flex items-center justify-center text-sm"
              >
                {loading ? (
                  <div className="w-5 h-5 border-2 border-slate-950 border-t-transparent rounded-full animate-spin"></div>
                ) : (
                  <>
                    <span>{isSignUp ? 'Create Student Account' : 'Sign In'}</span>
                    <ArrowRight className="w-4 h-4 ml-1.5" />
                  </>
                )}
              </button>

              <div className="text-center mt-4">
                <button
                  type="button"
                  onClick={() => setIsSignUp(!isSignUp)}
                  className="text-xs text-teal-400 hover:text-teal-300 font-semibold transition-colors"
                >
                  {isSignUp ? 'Already have an account? Sign In' : "Don't have an account? Sign Up"}
                </button>
              </div>
            </form>
          )}

          {/* PHONE + OTP FORM */}
          {activeTab === 'phone' && (
            <div className="space-y-4">
              {!otpSent ? (
                <form onSubmit={handleSendOtp} className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider">
                      Phone Number
                    </label>
                    <div className="mt-1 relative rounded-md shadow-sm">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Phone className="h-4 w-4 text-slate-400" />
                      </div>
                      <input
                        type="tel"
                        required
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        className="block w-full pl-10 pr-3 py-2 bg-slate-950/50 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-transparent text-sm"
                        placeholder="+15550188"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full py-2.5 px-4 bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500 flex items-center justify-center text-sm"
                  >
                    {loading ? (
                      <div className="w-5 h-5 border-2 border-slate-950 border-t-transparent rounded-full animate-spin"></div>
                    ) : (
                      <>
                        <span>Send 6-Digit OTP</span>
                        <ArrowRight className="w-4 h-4 ml-1.5" />
                      </>
                    )}
                  </button>
                </form>
              ) : (
                <form onSubmit={handleVerifyOtp} className="space-y-4">
                  {demoOtp && (
                    <div className="p-3 bg-teal-500/10 border border-teal-500/30 rounded-lg text-teal-400 text-xs flex flex-col space-y-1">
                      <div className="flex items-center space-x-1 font-bold">
                        <CheckCircle2 className="w-4 h-4" />
                        <span>Demo SMS Service (Auto-Generated OTP)</span>
                      </div>
                      <p>We've generated an OTP code for you to copy:</p>
                      <span className="text-lg font-mono font-bold tracking-widest text-white mt-1 bg-slate-950 px-2.5 py-1 rounded border border-slate-800 self-start">
                        {demoOtp}
                      </span>
                    </div>
                  )}

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider">
                      Enter Verification Code (OTP)
                    </label>
                    <input
                      type="text"
                      maxLength={6}
                      required
                      value={otp}
                      onChange={(e) => setOtp(e.target.value)}
                      className="mt-1 block w-full px-3 py-2 bg-slate-950/50 border border-slate-700 rounded-lg text-white placeholder-slate-500 tracking-widest text-center text-lg font-semibold focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-transparent"
                      placeholder="000000"
                    />
                  </div>

                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setOtpSent(false)}
                      className="flex-1 py-2 px-4 bg-slate-700 hover:bg-slate-600 text-white font-medium rounded-lg transition-colors text-xs"
                    >
                      Change Phone
                    </button>
                    <button
                      type="submit"
                      disabled={loading}
                      className="flex-1 py-2 px-4 bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold rounded-lg transition-colors flex items-center justify-center text-xs"
                    >
                      {loading ? (
                        <div className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin"></div>
                      ) : (
                        <span>Verify & Sign In</span>
                      )}
                    </button>
                  </div>
                </form>
              )}
            </div>
          )}

          {/* GOOGLE SIGN IN */}
          <div className="mt-6">
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-slate-700"></div>
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-slate-800 px-2 text-slate-400 font-semibold">Or continue with</span>
              </div>
            </div>

            <div className="mt-4">
              <button
                onClick={() => signInWithGoogle('Smart Admission Portal')}
                className="w-full flex items-center justify-center px-4 py-2 bg-slate-900 hover:bg-slate-950 border border-slate-700 hover:border-slate-600 rounded-lg text-slate-300 hover:text-white font-medium text-sm transition-all shadow-sm"
              >
                <svg className="w-5 h-5 mr-2" viewBox="0 0 24 24">
                  <path
                    fill="currentColor"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="currentColor"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="currentColor"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                  />
                  <path
                    fill="currentColor"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                  />
                </svg>
                <span>Sign in with Google</span>
              </button>
            </div>
          </div>

          {/* Test Credentials Helper */}
          <div className="mt-6 border-t border-slate-700/50 pt-4 text-xs text-slate-400 space-y-1">
            <p className="font-semibold text-slate-300">Quick Test Accounts:</p>
            <div className="flex justify-between">
              <span>Student: <strong className="text-teal-400 font-mono">student@example.com</strong></span>
              <span>Pass: <strong className="text-teal-400 font-mono">password123</strong></span>
            </div>
            <div className="flex justify-between">
              <span>Staff/Admin: <strong className="text-teal-400 font-mono">admin@smartadmission.edu</strong></span>
              <span>Pass: <strong className="text-teal-400 font-mono">adminsecure123</strong></span>
            </div>
            <p className="text-[10px] text-slate-500 italic mt-1">
              To test staff registration, click "Sign Up" and enter <strong className="text-slate-400 font-mono">STAFF2025</strong> in the promotion code field.
            </p>
          </div>

        </div>
      </div>
    </div>
  );
}
