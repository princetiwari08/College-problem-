import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Search, Filter, ClipboardList, CheckCircle, XCircle, Clock, Eye, X, GraduationCap, School, Sparkles } from 'lucide-react';

export default function StaffDashboard() {
  const { user } = useAuth();
  const [submissions, setSubmissions] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  // Search & Filter state
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [formTypeFilter, setFormTypeFilter] = useState('');

  // Selected submission modal detail
  const [selectedSubmission, setSelectedSubmission] = useState<any | null>(null);
  const [updatingStatus, setUpdatingStatus] = useState<string | null>(null);

  // Fetch all submissions for staff
  const fetchSubmissions = async () => {
    if (!user) return;
    setLoading(true);
    try {
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (user.token) {
        headers['Authorization'] = `Bearer ${user.token}`;
      } else if (user.id) {
        headers['X-User-Id'] = user.id;
      }

      // Build query string
      const params = new URLSearchParams();
      if (search) params.append('search', search);
      if (statusFilter) params.append('status', statusFilter);
      if (formTypeFilter) params.append('form_type', formTypeFilter);

      const res = await fetch(`/api/submissions?${params.toString()}`, { headers });
      if (res.ok) {
        const data = await res.json();
        setSubmissions(data);
      }
    } catch (err) {
      console.error('Error fetching submissions for staff:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSubmissions();
  }, [user, statusFilter, formTypeFilter]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchSubmissions();
  };

  const handleUpdateStatus = async (id: string, status: string) => {
    if (!user) return;
    setUpdatingStatus(id);
    try {
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (user.token) {
        headers['Authorization'] = `Bearer ${user.token}`;
      } else if (user.id) {
        headers['X-User-Id'] = user.id;
      }

      const res = await fetch('/api/submissions', {
        method: 'PUT',
        headers,
        body: JSON.stringify({ id, status })
      });

      if (res.ok) {
        // Update local state smoothly
        setSubmissions((prev: any[]) => prev.map(sub => sub.id === id ? { ...sub, status } : sub));
        if (selectedSubmission && selectedSubmission.id === id) {
          setSelectedSubmission((prev: any) => prev ? { ...prev, status } : null);
        }
      }
    } catch (err) {
      console.error('Error updating status:', err);
    } finally {
      setUpdatingStatus(null);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 pb-16">
      {/* Top Staff Banner */}
      <div className="bg-slate-900 text-white py-12 px-4 sm:px-6 lg:px-8 border-b border-slate-800">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <div className="flex items-center space-x-2">
              <ClipboardList className="w-6 h-6 text-teal-400" />
              <span className="text-xs text-teal-400 font-bold uppercase tracking-widest bg-teal-400/10 px-2.5 py-1 rounded-full border border-teal-500/20">
                Staff Control Panel
              </span>
            </div>
            <h1 className="text-3xl font-bold tracking-tight mt-2">Admissions Office Dashboard</h1>
            <p className="text-slate-400 mt-2 text-sm max-w-xl">
              Inspect submitted forms, search student records, verify previous academic scores, and manage application statuses.
            </p>
          </div>
          <div className="flex bg-slate-800 border border-slate-700 rounded-2xl p-4 space-x-6">
            <div className="text-center">
              <span className="text-xs text-slate-400 block font-medium">Pending Review</span>
              <span className="text-xl font-bold text-amber-400 mt-0.5 block">
                {submissions.filter(s => s.status === 'pending').length}
              </span>
            </div>
            <div className="w-px bg-slate-700"></div>
            <div className="text-center">
              <span className="text-xs text-slate-400 block font-medium">Total Received</span>
              <span className="text-xl font-bold text-white mt-0.5 block">
                {submissions.length}
              </span>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-10 space-y-6">
        {/* Search and Filters Bar */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-5 shadow-sm flex flex-col lg:flex-row lg:items-center gap-4">
          <form onSubmit={handleSearchSubmit} className="flex-1 relative">
            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
              <Search className="h-4 w-4 text-slate-400" />
            </div>
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="block w-full pl-10 pr-24 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500"
              placeholder="Search by student name, email, Aadhar/ID..."
            />
            <button
              type="submit"
              className="absolute right-1.5 top-1.5 bottom-1.5 px-4 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-lg transition-colors"
            >
              Search
            </button>
          </form>

          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center space-x-2">
              <Filter className="w-4 h-4 text-slate-400" />
              <span className="text-xs font-bold text-slate-500 uppercase">Filters:</span>
            </div>

            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="bg-slate-50 border border-slate-200 px-3 py-2 rounded-xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-teal-500/20"
            >
              <option value="">All Statuses</option>
              <option value="pending">Pending</option>
              <option value="approved">Approved</option>
              <option value="rejected">Rejected</option>
            </select>

            <select
              value={formTypeFilter}
              onChange={(e) => setFormTypeFilter(e.target.value)}
              className="bg-slate-50 border border-slate-200 px-3 py-2 rounded-xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-teal-500/20"
            >
              <option value="">All Form Types</option>
              <option value="admission_enquiry">Admission Enquiry</option>
              <option value="scholarship_application">Scholarship Application</option>
            </select>

            {(search || statusFilter || formTypeFilter) && (
              <button
                onClick={() => {
                  setSearch('');
                  setStatusFilter('');
                  setFormTypeFilter('');
                }}
                className="text-xs text-rose-600 hover:text-rose-700 font-bold hover:underline"
              >
                Clear All
              </button>
            )}
          </div>
        </div>

        {/* Submissions Table / Cards */}
        {loading ? (
          <div className="bg-white border border-slate-200 rounded-2xl p-12 text-center shadow-sm">
            <div className="w-10 h-10 border-3 border-teal-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-sm text-slate-500">Loading student applications...</p>
          </div>
        ) : submissions.length === 0 ? (
          <div className="bg-white border border-slate-200 rounded-2xl p-16 text-center shadow-sm space-y-4">
            <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center text-slate-400 mx-auto border border-slate-100">
              <ClipboardList className="w-8 h-8" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-lg">No matching submissions found</h3>
              <p className="text-sm text-slate-500 mt-1 max-w-md mx-auto">
                No forms meet your current filter criteria. Check your spelling or try clearing active filters.
              </p>
            </div>
          </div>
        ) : (
          <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-xs font-bold text-slate-500 uppercase tracking-wider">
                    <th className="px-6 py-4">Student Name</th>
                    <th className="px-6 py-4">Form Type</th>
                    <th className="px-6 py-4">Course of Interest</th>
                    <th className="px-6 py-4">Marks %</th>
                    <th className="px-6 py-4">Status</th>
                    <th className="px-6 py-4">Submitted Date</th>
                    <th className="px-6 py-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-sm">
                  {submissions.map((sub) => (
                    <tr key={sub.id} className="hover:bg-slate-50/40 transition-colors">
                      <td className="px-6 py-4">
                        <div className="font-semibold text-slate-900">{sub.full_name}</div>
                        <div className="text-xs text-slate-400">{sub.email || sub.phone}</div>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`inline-flex items-center space-x-1 px-2.5 py-1 rounded-full text-xs font-bold ${
                          sub.form_type === 'admission_enquiry'
                            ? 'bg-blue-50 text-blue-700 border border-blue-100'
                            : 'bg-indigo-50 text-indigo-700 border border-indigo-100'
                        }`}>
                          {sub.form_type === 'admission_enquiry' ? (
                            <>
                              <School className="w-3 h-3" />
                              <span>Enquiry</span>
                            </>
                          ) : (
                            <>
                              <GraduationCap className="w-3 h-3" />
                              <span>Scholarship</span>
                            </>
                          )}
                        </span>
                      </td>
                      <td className="px-6 py-4 font-medium text-slate-700">
                        {sub.course_of_interest}
                      </td>
                      <td className="px-6 py-4 font-bold text-slate-900">
                        {sub.marks_percentage}%
                      </td>
                      <td className="px-6 py-4">
                        <span className={`inline-flex items-center space-x-1 px-2.5 py-1 rounded-full text-xs font-bold ${
                          sub.status === 'approved'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-100'
                            : sub.status === 'rejected'
                            ? 'bg-rose-50 text-rose-700 border border-rose-100'
                            : 'bg-amber-50 text-amber-700 border border-amber-100'
                        }`}>
                          {sub.status === 'approved' && <CheckCircle className="w-3 h-3" />}
                          {sub.status === 'rejected' && <XCircle className="w-3 h-3" />}
                          {sub.status === 'pending' && <Clock className="w-3 h-3 animate-pulse" />}
                          <span className="capitalize">{sub.status}</span>
                        </span>
                      </td>
                      <td className="px-6 py-4 text-slate-500">
                        {new Date(sub.created_at).toLocaleDateString(undefined, {
                          month: 'short',
                          day: 'numeric',
                          year: 'numeric'
                        })}
                      </td>
                      <td className="px-6 py-4 text-right">
                        <button
                          onClick={() => setSelectedSubmission(sub)}
                          className="p-2 bg-slate-100 hover:bg-slate-200 text-slate-700 hover:text-slate-900 rounded-lg transition-colors inline-flex items-center justify-center"
                          title="View Details"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* DETAILED SUBMISSION INSPECTOR MODAL */}
      {selectedSubmission && (
        <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-white rounded-3xl border border-slate-200 max-w-3xl w-full shadow-2xl overflow-hidden animate-scale-up">
            {/* Modal Header */}
            <div className="bg-slate-900 text-white px-6 py-5 flex items-center justify-between border-b border-slate-800">
              <div>
                <span className="text-[10px] uppercase font-bold tracking-widest text-teal-400">
                  Submission ID: #{selectedSubmission.id}
                </span>
                <h3 className="text-xl font-bold mt-0.5">
                  {selectedSubmission.form_type === 'admission_enquiry'
                    ? 'Admission Enquiry Details'
                    : 'Scholarship Application Details'}
                </h3>
              </div>
              <button
                onClick={() => setSelectedSubmission(null)}
                className="p-1.5 bg-slate-800 hover:bg-slate-700 rounded-full transition-colors text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-6 space-y-6 max-h-[70vh] overflow-y-auto">
              {/* Profile Card Summary */}
              <div className="bg-slate-50 rounded-2xl p-5 border border-slate-100 space-y-4">
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center space-x-1 border-b border-slate-200 pb-2">
                  <Eye className="w-4 h-4 text-teal-600" />
                  <span>Master Profile Details</span>
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-3 text-sm">
                  <div>
                    <span className="text-slate-400 block text-xs">Full Name</span>
                    <span className="font-semibold text-slate-800">{selectedSubmission.full_name}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-xs">Aadhar / ID Number</span>
                    <span className="font-semibold text-slate-800">{selectedSubmission.id_number}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-xs">Date of Birth (DOB)</span>
                    <span className="font-semibold text-slate-800">{selectedSubmission.dob}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-xs">Gender</span>
                    <span className="font-semibold text-slate-800">{selectedSubmission.gender}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-xs">Phone Number</span>
                    <span className="font-semibold text-slate-800">{selectedSubmission.phone}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-xs">Email Address</span>
                    <span className="font-semibold text-slate-800">{selectedSubmission.email}</span>
                  </div>
                  <div className="sm:col-span-2">
                    <span className="text-slate-400 block text-xs">Residential Address</span>
                    <span className="font-semibold text-slate-800 leading-relaxed">{selectedSubmission.address}</span>
                  </div>
                </div>
              </div>

              {/* Academic Scores details */}
              <div className="bg-slate-50 rounded-2xl p-5 border border-slate-100 space-y-4">
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center space-x-1 border-b border-slate-200 pb-2">
                  <GraduationCap className="w-4 h-4 text-teal-600" />
                  <span>Academic Qualifications</span>
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-sm">
                  <div className="sm:col-span-2">
                    <span className="text-slate-400 block text-xs">Last Institute Attended</span>
                    <span className="font-semibold text-slate-800">{selectedSubmission.last_school}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-xs">Aggregate Score / Marks %</span>
                    <span className="font-bold text-teal-600">{selectedSubmission.marks_percentage}%</span>
                  </div>
                  <div className="sm:col-span-3">
                    <span className="text-slate-400 block text-xs">Course Applied For</span>
                    <span className="font-semibold text-slate-800">{selectedSubmission.course_of_interest}</span>
                  </div>
                </div>
              </div>

              {/* Form Specific Answers */}
              <div className="bg-slate-50 rounded-2xl p-5 border border-slate-100 space-y-4">
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center space-x-1 border-b border-slate-200 pb-2">
                  <Sparkles className="w-4 h-4 text-teal-600" />
                  <span>Form-Specific Questionnaire Answers</span>
                </h4>

                {selectedSubmission.form_type === 'admission_enquiry' ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-slate-400 block text-xs">Academic Year Preference</span>
                      <span className="font-semibold text-slate-800">
                        {selectedSubmission.additional_details?.academic_year || '2025-2026'}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-xs">Preferred Study Batch</span>
                      <span className="font-semibold text-slate-800">
                        {selectedSubmission.additional_details?.preferred_batch || 'Not Specified'}
                      </span>
                    </div>
                    <div className="sm:col-span-2">
                      <span className="text-slate-400 block text-xs">Specific Questions / Queries</span>
                      <p className="font-medium text-slate-700 bg-white p-3 rounded-xl border border-slate-200 mt-1 leading-relaxed">
                        {selectedSubmission.additional_details?.questions || 'None'}
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4 text-sm">
                    <div>
                      <span className="text-slate-400 block text-xs">Annual Family Income</span>
                      <span className="font-bold text-emerald-600">
                        ${parseFloat(selectedSubmission.additional_details?.annual_family_income || 0).toLocaleString()}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-xs">Reason for Scholarship</span>
                      <p className="font-medium text-slate-700 bg-white p-3 rounded-xl border border-slate-200 mt-1 leading-relaxed">
                        {selectedSubmission.additional_details?.scholarship_reason || 'Not Specified'}
                      </p>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-xs">Statement of Purpose (SOP)</span>
                      <p className="font-medium text-slate-700 bg-white p-3 rounded-xl border border-slate-200 mt-1 leading-relaxed whitespace-pre-line">
                        {selectedSubmission.additional_details?.statement_of_purpose || 'Not Specified'}
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Modal Footer / Verification Actions */}
            <div className="bg-slate-50 px-6 py-4 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              <div className="flex items-center space-x-2">
                <span className="text-xs text-slate-400 font-medium">Current Status:</span>
                <span className={`inline-flex items-center space-x-1 px-2.5 py-1 rounded-full text-xs font-bold capitalize ${
                  selectedSubmission.status === 'approved'
                    ? 'bg-emerald-50 text-emerald-700 border border-emerald-100'
                    : selectedSubmission.status === 'rejected'
                    ? 'bg-rose-50 text-rose-700 border border-rose-100'
                    : 'bg-amber-50 text-amber-700 border border-amber-100'
                }`}>
                  {selectedSubmission.status}
                </span>
              </div>

              <div className="flex items-center space-x-2 self-end sm:self-center">
                <button
                  onClick={() => handleUpdateStatus(selectedSubmission.id, 'rejected')}
                  disabled={updatingStatus === selectedSubmission.id}
                  className="px-4 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-xs font-bold rounded-xl transition-colors disabled:opacity-50 flex items-center space-x-1"
                >
                  <XCircle className="w-4 h-4" />
                  <span>Reject Application</span>
                </button>
                <button
                  onClick={() => handleUpdateStatus(selectedSubmission.id, 'approved')}
                  disabled={updatingStatus === selectedSubmission.id}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-sm transition-colors disabled:opacity-50 flex items-center space-x-1"
                >
                  <CheckCircle className="w-4 h-4" />
                  <span>Approve & Verify</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
