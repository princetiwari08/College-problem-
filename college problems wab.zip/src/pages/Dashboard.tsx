import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { User, ClipboardCopy, ArrowRight, CheckCircle, Clock, AlertCircle, Sparkles, School, GraduationCap } from 'lucide-react';

export default function Dashboard() {
  const { user, profile } = useAuth();
  const [submissions, setSubmissions] = useState<any[]>([]);
  const [loadingSubmissions, setLoadingSubmissions] = useState(true);

  useEffect(() => {
    const fetchSubmissions = async () => {
      if (!user) return;
      try {
        const headers: Record<string, string> = { 'Content-Type': 'application/json' };
        if (user.token) {
          headers['Authorization'] = `Bearer ${user.token}`;
        } else if (user.id) {
          headers['X-User-Id'] = user.id;
        }

        const res = await fetch('/api/submissions', { headers });
        if (res.ok) {
          const data = await res.json();
          setSubmissions(data);
        }
      } catch (err) {
        console.error('Error fetching submissions:', err);
      } finally {
        setLoadingSubmissions(false);
      }
    };

    fetchSubmissions();
  }, [user]);

  const isProfileComplete = profile && profile.full_name && profile.dob && profile.phone;

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 pb-12">
      {/* Header Banner */}
      <div className="bg-slate-900 text-white py-12 px-4 sm:px-6 lg:px-8 border-b border-slate-800">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center md:justify-between gap-6">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">
              Welcome back, {profile?.full_name || 'Student'}!
            </h1>
            <p className="text-slate-400 mt-2 max-w-2xl text-sm">
              EduSmart automates college admission processes. Fill your profile once, and use OCR or database auto-fills to apply to any form in seconds.
            </p>
          </div>
          <div className="flex items-center space-x-3">
            <span className="text-xs bg-slate-800 border border-slate-700 px-3 py-1.5 rounded-full font-medium text-slate-300">
              User ID: {user?.id?.slice(0, 8)}...
            </span>
            <span className={`text-xs px-3 py-1.5 rounded-full font-bold ${
              isProfileComplete ? 'bg-teal-500/10 text-teal-400 border border-teal-500/20' : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
            }`}>
              {isProfileComplete ? '● Profile Active' : '○ Profile Incomplete'}
            </span>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-10 grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left/Middle: Actions & Forms */}
        <div className="lg:col-span-2 space-y-8">
          {/* Profile Status Alert */}
          {!isProfileComplete && (
            <div className="bg-amber-50 border border-amber-200 rounded-2xl p-5 flex items-start space-x-4 shadow-sm">
              <AlertCircle className="w-6 h-6 text-amber-600 shrink-0 mt-0.5" />
              <div className="flex-1">
                <h3 className="font-bold text-amber-900 text-base">Complete your One-Time Profile Setup</h3>
                <p className="text-sm text-amber-700 mt-1">
                  You need to fill out your master profile details to unlock seamless form auto-fills. You can also upload your marksheet/ID card to scan and auto-populate your details using AI OCR!
                </p>
                <div className="mt-4">
                  <Link
                    to="/profile-setup"
                    className="inline-flex items-center space-x-1.5 bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold px-4 py-2 rounded-lg transition-colors shadow-sm"
                  >
                    <Sparkles className="w-4 h-4" />
                    <span>Setup Profile with OCR</span>
                  </Link>
                </div>
              </div>
            </div>
          )}

          {/* Available Forms */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold text-slate-900 flex items-center space-x-2">
                <School className="w-5 h-5 text-teal-600" />
                <span>Available Applications & Forms</span>
              </h2>
              {isProfileComplete && (
                <span className="text-xs font-semibold text-teal-600 bg-teal-50 px-2.5 py-1 rounded-full border border-teal-100 flex items-center space-x-1">
                  <Sparkles className="w-3 h-3" />
                  <span>Autofill Ready</span>
                </span>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Form 1: Admission Enquiry */}
              <div className="bg-white border border-slate-200 hover:border-teal-500 rounded-2xl p-6 shadow-sm hover:shadow-md transition-all flex flex-col justify-between group">
                <div>
                  <div className="w-12 h-12 bg-slate-100 group-hover:bg-teal-50 rounded-xl flex items-center justify-center text-slate-700 group-hover:text-teal-600 transition-colors mb-4">
                    <School className="w-6 h-6" />
                  </div>
                  <h3 className="font-bold text-slate-900 text-lg group-hover:text-teal-600 transition-colors">
                    Admission Enquiry Form
                  </h3>
                  <p className="text-sm text-slate-500 mt-2 leading-relaxed">
                    Submit an enquiry for your preferred courses, batch timings, and general questions regarding the current academic year.
                  </p>
                </div>
                <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between">
                  <span className="text-xs text-slate-400">Takes ~15 seconds</span>
                  <Link
                    to="/form/admission-enquiry"
                    className="inline-flex items-center space-x-1 text-sm font-bold text-teal-600 group-hover:text-teal-700 hover:underline"
                  >
                    <span>Apply Now</span>
                    <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </Link>
                </div>
              </div>

              {/* Form 2: Scholarship Application */}
              <div className="bg-white border border-slate-200 hover:border-teal-500 rounded-2xl p-6 shadow-sm hover:shadow-md transition-all flex flex-col justify-between group">
                <div>
                  <div className="w-12 h-12 bg-slate-100 group-hover:bg-teal-50 rounded-xl flex items-center justify-center text-slate-700 group-hover:text-teal-600 transition-colors mb-4">
                    <GraduationCap className="w-6 h-6" />
                  </div>
                  <h3 className="font-bold text-slate-900 text-lg group-hover:text-teal-600 transition-colors">
                    Scholarship Application Form
                  </h3>
                  <p className="text-sm text-slate-500 mt-2 leading-relaxed">
                    Apply for financial assistance or academic merit-based scholarships. Requires family income details and a brief statement of purpose.
                  </p>
                </div>
                <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between">
                  <span className="text-xs text-slate-400">Takes ~20 seconds</span>
                  <Link
                    to="/form/scholarship-application"
                    className="inline-flex items-center space-x-1 text-sm font-bold text-teal-600 group-hover:text-teal-700 hover:underline"
                  >
                    <span>Apply Now</span>
                    <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </Link>
                </div>
              </div>
            </div>
          </div>

          {/* Submissions History */}
          <div>
            <h2 className="text-xl font-bold text-slate-900 flex items-center space-x-2 mb-4">
              <ClipboardCopy className="w-5 h-5 text-teal-600" />
              <span>Your Submitted Applications</span>
            </h2>

            {loadingSubmissions ? (
              <div className="bg-white border border-slate-200 rounded-2xl p-8 text-center shadow-sm">
                <div className="w-8 h-8 border-3 border-teal-600 border-t-transparent rounded-full animate-spin mx-auto mb-3"></div>
                <p className="text-sm text-slate-500">Loading submission history...</p>
              </div>
            ) : submissions.length === 0 ? (
              <div className="bg-white border border-slate-200 rounded-2xl p-10 text-center shadow-sm space-y-3">
                <div className="w-12 h-12 bg-slate-50 rounded-full flex items-center justify-center text-slate-400 mx-auto">
                  <ClipboardCopy className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900">No applications submitted yet</h3>
                  <p className="text-sm text-slate-500 mt-1">
                    Your submitted forms will appear here along with their verification status.
                  </p>
                </div>
              </div>
            ) : (
              <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-sm">
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-slate-50 border-b border-slate-200 text-xs font-bold text-slate-500 uppercase tracking-wider">
                        <th className="px-6 py-3.5">Form Name</th>
                        <th className="px-6 py-3.5">Submission Date</th>
                        <th className="px-6 py-3.5">Verification Status</th>
                        <th className="px-6 py-3.5 text-right">Details</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-sm">
                      {submissions.map((sub) => (
                        <tr key={sub.id} className="hover:bg-slate-50/50 transition-colors">
                          <td className="px-6 py-4 font-semibold text-slate-900">
                            {sub.form_type === 'admission_enquiry' ? 'Admission Enquiry' : 'Scholarship Application'}
                          </td>
                          <td className="px-6 py-4 text-slate-500">
                            {new Date(sub.created_at).toLocaleDateString(undefined, {
                              year: 'numeric',
                              month: 'long',
                              day: 'numeric'
                            })}
                          </td>
                          <td className="px-6 py-4">
                            <span className={`inline-flex items-center space-x-1 px-2.5 py-1 rounded-full text-xs font-bold ${
                              sub.status === 'approved'
                                ? 'bg-emerald-50 text-emerald-700 border border-emerald-100'
                                : sub.status === 'rejected'
                                ? 'bg-rose-50 text-rose-700 border border-rose-100'
                                : 'bg-amber-50 text-amber-700 border border-amber-100'
                            }`}>
                              {sub.status === 'approved' && <CheckCircle className="w-3.5 h-3.5" />}
                              {sub.status === 'rejected' && <AlertCircle className="w-3.5 h-3.5" />}
                              {sub.status === 'pending' && <Clock className="w-3.5 h-3.5 animate-pulse" />}
                              <span className="capitalize">{sub.status}</span>
                            </span>
                          </td>
                          <td className="px-6 py-4 text-right">
                            <span className="text-xs text-slate-400">
                              ID: #{sub.id}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right Side: Profile Summary Quick Card */}
        <div className="space-y-6">
          <div className="bg-white border border-slate-200 rounded-2xl shadow-sm p-6">
            <h3 className="font-bold text-slate-900 text-lg flex items-center space-x-2 border-b border-slate-100 pb-4 mb-4">
              <User className="w-5 h-5 text-teal-600" />
              <span>Master Profile Summary</span>
            </h3>

            {isProfileComplete && profile ? (
              <div className="space-y-4">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-teal-50 rounded-full flex items-center justify-center text-teal-600 font-bold text-base">
                    {profile.full_name.charAt(0)}
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900 text-sm leading-tight">{profile.full_name}</h4>
                    <p className="text-xs text-slate-500 mt-0.5">{profile.email || 'No email saved'}</p>
                  </div>
                </div>

                <div className="divide-y divide-slate-100 text-xs space-y-2.5 pt-2">
                  <div className="flex justify-between pt-2">
                    <span className="text-slate-400 font-medium">Date of Birth:</span>
                    <span className="text-slate-700 font-semibold">{profile.dob}</span>
                  </div>
                  <div className="flex justify-between pt-2">
                    <span className="text-slate-400 font-medium">Phone Number:</span>
                    <span className="text-slate-700 font-semibold">{profile.phone}</span>
                  </div>
                  <div className="flex justify-between pt-2">
                    <span className="text-slate-400 font-medium">Aadhar / ID:</span>
                    <span className="text-slate-700 font-semibold">{profile.id_number}</span>
                  </div>
                  <div className="flex justify-between pt-2">
                    <span className="text-slate-400 font-medium">Previous School:</span>
                    <span className="text-slate-700 font-semibold truncate max-w-[150px]" title={profile.last_school}>
                      {profile.last_school}
                    </span>
                  </div>
                  <div className="flex justify-between pt-2">
                    <span className="text-slate-400 font-medium">Academic Marks:</span>
                    <span className="text-slate-700 font-semibold">{profile.marks_percentage}%</span>
                  </div>
                </div>

                <div className="pt-4 mt-2">
                  <Link
                    to="/profile-setup"
                    className="w-full text-center block bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold py-2.5 px-4 rounded-xl transition-colors shadow-sm"
                  >
                    Edit Master Profile
                  </Link>
                </div>
              </div>
            ) : (
              <div className="text-center py-6 space-y-4">
                <div className="w-12 h-12 bg-slate-50 border border-slate-100 rounded-full flex items-center justify-center text-slate-400 mx-auto">
                  <User className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-sm font-semibold text-slate-800">Your profile is empty</p>
                  <p className="text-xs text-slate-500 mt-1">
                    Fill your master profile once to enable autofill on all forms.
                  </p>
                </div>
                <Link
                  to="/profile-setup"
                  className="w-full text-center block bg-teal-500 hover:bg-teal-400 text-slate-950 text-xs font-bold py-2.5 px-4 rounded-xl transition-colors shadow-sm"
                >
                  Setup Profile Now
                </Link>
              </div>
            )}
          </div>

          {/* Autofill security helper */}
          <div className="bg-slate-900 text-slate-300 rounded-2xl p-5 border border-slate-800 space-y-3 shadow-sm">
            <h4 className="font-bold text-white text-sm flex items-center space-x-1.5">
              <Sparkles className="w-4 h-4 text-teal-400" />
              <span>How Autofill Works</span>
            </h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              When you load any form on this portal, EduSmart queries the database for your fresh master profile and auto-fills every matching input field.
            </p>
            <p className="text-xs text-slate-400 leading-relaxed">
              You can always edit any field before hitting submit. Editing fields on a form won't overwrite your master profile unless you edit it directly.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
