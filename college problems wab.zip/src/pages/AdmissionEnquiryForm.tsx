import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { Sparkles, Save, CheckCircle, AlertCircle, Calendar, BookOpen, User } from 'lucide-react';

export default function AdmissionEnquiryForm() {
  const { user } = useAuth();
  const navigate = useNavigate();

  // Master Profile state (to confirm if loaded)
  const [profileLoaded, setProfileLoaded] = useState(false);
  const [autofillTriggered, setAutofillTriggered] = useState(false);

  // Form Fields
  const [fullName, setFullName] = useState('');
  const [dob, setDob] = useState('');
  const [gender, setGender] = useState('');
  const [address, setAddress] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [idNumber, setIdNumber] = useState('');
  const [courseOfInterest, setCourseOfInterest] = useState('');
  const [lastSchool, setLastSchool] = useState('');
  const [marksPercentage, setMarksPercentage] = useState('');

  // Additional form-specific fields
  const [preferredBatch, setPreferredBatch] = useState('');
  const [academicYear, setAcademicYear] = useState('2025-2026');
  const [questions, setQuestions] = useState('');

  // Submission States
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');

  // Fetch FRESH profile details directly from DB on load to prevent stale autofill
  useEffect(() => {
    const fetchFreshProfile = async () => {
      if (!user) return;
      try {
        const headers: Record<string, string> = { 'Content-Type': 'application/json' };
        if (user.token) {
          headers['Authorization'] = `Bearer ${user.token}`;
        } else if (user.id) {
          headers['X-User-Id'] = user.id;
        }

        const res = await fetch('/api/profile', { headers });
        if (res.ok) {
          const freshProfile = await res.json();
          if (freshProfile) {
            setFullName(freshProfile.full_name || '');
            setDob(freshProfile.dob || '');
            setGender(freshProfile.gender || '');
            setAddress(freshProfile.address || '');
            setPhone(freshProfile.phone || '');
            setEmail(freshProfile.email || user.email || '');
            setIdNumber(freshProfile.id_number || '');
            setCourseOfInterest(freshProfile.course_of_interest || '');
            setLastSchool(freshProfile.last_school || '');
            setMarksPercentage(freshProfile.marks_percentage || '');
            setProfileLoaded(true);
            setAutofillTriggered(true);

            // Auto-clear success state after a few seconds
            setTimeout(() => setAutofillTriggered(false), 4000);
          }
        }
      } catch (err) {
        console.error('Error fetching fresh profile for autofill:', err);
      }
    };

    fetchFreshProfile();
  }, [user]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setSubmitting(true);
    setError('');
    setSuccess(false);

    try {
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (user.token) {
        headers['Authorization'] = `Bearer ${user.token}`;
      } else if (user.id) {
        headers['X-User-Id'] = user.id;
      }

      const res = await fetch('/api/submissions', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          form_type: 'admission_enquiry',
          full_name: fullName,
          dob,
          gender,
          address,
          phone,
          email,
          id_number: idNumber,
          course_of_interest: courseOfInterest,
          last_school: lastSchool,
          marks_percentage: marksPercentage,
          additional_details: {
            preferred_batch: preferredBatch,
            academic_year: academicYear,
            questions: questions
          }
        })
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to submit form');

      setSuccess(true);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 pb-16">
      {/* Header */}
      <div className="bg-slate-900 text-white py-12 px-4 sm:px-6 lg:px-8 border-b border-slate-800">
        <div className="max-w-4xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Admission Enquiry Form</h1>
            <p className="text-slate-400 mt-2 text-sm">
              Use this form to enquire about your preferred courses, batches, and timing details.
            </p>
          </div>
          <button
            onClick={() => navigate('/dashboard')}
            className="text-xs bg-slate-800 border border-slate-700 hover:bg-slate-700 px-4 py-2 rounded-xl text-slate-300 font-semibold self-start md:self-center transition-colors"
          >
            ← Back to Dashboard
          </button>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 mt-10">
        {/* Autofill Alert */}
        {autofillTriggered && (
          <div className="bg-teal-50 border border-teal-200 rounded-2xl p-4 mb-6 flex items-center space-x-3 shadow-sm animate-pulse">
            <Sparkles className="w-5 h-5 text-teal-600 shrink-0" />
            <span className="text-sm text-teal-800 font-medium">
              ⚡ <strong>Autofill Magic!</strong> We've filled out this form using your latest saved profile. You can still modify any field before submitting.
            </span>
          </div>
        )}

        {success && (
          <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-6 mb-8 flex flex-col items-center text-center shadow-sm">
            <CheckCircle className="w-12 h-12 text-emerald-600 mb-3" />
            <h3 className="font-bold text-emerald-900 text-lg">Enquiry Submitted Successfully!</h3>
            <p className="text-sm text-emerald-700 mt-1 max-w-md">
              Your admission enquiry has been saved and sent to the admissions office. Staff will review your details and contact you shortly.
            </p>
            <button
              onClick={() => navigate('/dashboard')}
              className="mt-5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs px-5 py-2.5 rounded-xl transition-colors shadow-sm"
            >
              Go to My Dashboard
            </button>
          </div>
        )}

        {error && (
          <div className="bg-rose-50 border border-rose-200 rounded-2xl p-5 mb-8 flex items-center space-x-4 shadow-sm">
            <AlertCircle className="w-8 h-8 text-rose-600 shrink-0" />
            <div>
              <h3 className="font-bold text-rose-900 text-base">Submission Failed</h3>
              <p className="text-sm text-rose-700 mt-0.5">{error}</p>
            </div>
          </div>
        )}

        {!success && (
          <form onSubmit={handleSubmit} className="bg-white border border-slate-200 rounded-2xl shadow-sm p-6 sm:p-8 space-y-8">
            {/* Section 1: Auto-filled master details */}
            <div className="space-y-4">
              <div className="flex justify-between items-center border-b border-slate-100 pb-3">
                <h3 className="font-bold text-slate-900 text-base flex items-center space-x-2">
                  <User className="w-5 h-5 text-teal-600" />
                  <span>Personal Details (Autofilled)</span>
                </h3>
                {!profileLoaded && (
                  <span className="text-xs text-amber-600 bg-amber-50 px-2.5 py-1 rounded-full border border-amber-100 font-semibold">
                    No Profile Found - Enter Manually
                  </span>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Full Name</label>
                  <input
                    type="text"
                    required
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="block w-full px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Date of Birth</label>
                  <input
                    type="date"
                    required
                    value={dob}
                    onChange={(e) => setDob(e.target.value)}
                    className="block w-full px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Gender</label>
                  <select
                    required
                    value={gender}
                    onChange={(e) => setGender(e.target.value)}
                    className="block w-full px-3.5 py-2 border border-slate-200 rounded-xl text-sm bg-white focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500"
                  >
                    <option value="">Select Gender</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Non-binary">Non-binary</option>
                    <option value="Other">Other</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Aadhar / ID Number</label>
                  <input
                    type="text"
                    required
                    value={idNumber}
                    onChange={(e) => setIdNumber(e.target.value)}
                    className="block w-full px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Phone Number</label>
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="block w-full px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Email Address</label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="block w-full px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-500 mb-1">Residential Address</label>
                <textarea
                  required
                  rows={2}
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="block w-full px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500"
                ></textarea>
              </div>
            </div>

            {/* Section 2: Auto-filled academic details */}
            <div className="space-y-4 pt-6 border-t border-slate-100">
              <h3 className="font-bold text-slate-900 text-base flex items-center space-x-2 border-b border-slate-100 pb-3">
                <BookOpen className="w-5 h-5 text-teal-600" />
                <span>Academic Information (Autofilled)</span>
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="md:col-span-2">
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Last School/College Attended</label>
                  <input
                    type="text"
                    required
                    value={lastSchool}
                    onChange={(e) => setLastSchool(e.target.value)}
                    className="block w-full px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Marks / Percentage (%)</label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    value={marksPercentage}
                    onChange={(e) => setMarksPercentage(e.target.value)}
                    className="block w-full px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-500 mb-1">Course of Interest</label>
                <select
                  required
                  value={courseOfInterest}
                  onChange={(e) => setCourseOfInterest(e.target.value)}
                  className="block w-full px-3.5 py-2 border border-slate-200 rounded-xl text-sm bg-white focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500"
                >
                  <option value="">Select Course</option>
                  <option value="Computer Science">Computer Science (B.Sc)</option>
                  <option value="Information Technology">Information Technology (B.Tech)</option>
                  <option value="Business Administration">Business Administration (BBA)</option>
                  <option value="Data Science">Data Science (M.Sc)</option>
                  <option value="Electrical Engineering">Electrical Engineering (B.E)</option>
                </select>
              </div>
            </div>

            {/* Section 3: Form-Specific Questions */}
            <div className="space-y-4 pt-6 border-t border-slate-100">
              <h3 className="font-bold text-slate-900 text-base flex items-center space-x-2 border-b border-slate-100 pb-3">
                <Calendar className="w-5 h-5 text-teal-600" />
                <span>Enquiry & Batch Details (Form Specific)</span>
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Academic Year *</label>
                  <select
                    required
                    value={academicYear}
                    onChange={(e) => setAcademicYear(e.target.value)}
                    className="block w-full px-3.5 py-2 border border-slate-200 rounded-xl text-sm bg-white focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500"
                  >
                    <option value="2025-2026">2025-2026</option>
                    <option value="2026-2027">2026-2027</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Preferred Batch *</label>
                  <select
                    required
                    value={preferredBatch}
                    onChange={(e) => setPreferredBatch(e.target.value)}
                    className="block w-full px-3.5 py-2 border border-slate-200 rounded-xl text-sm bg-white focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500"
                  >
                    <option value="">Select Batch Preference</option>
                    <option value="Morning">Morning Batch (8:00 AM - 1:00 PM)</option>
                    <option value="Afternoon">Afternoon Batch (1:30 PM - 6:30 PM)</option>
                    <option value="Evening">Evening Batch (5:00 PM - 9:00 PM)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-500 mb-1">Specific Queries / Questions</label>
                <textarea
                  rows={3}
                  value={questions}
                  onChange={(e) => setQuestions(e.target.value)}
                  className="block w-full px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500"
                  placeholder="Enter any questions you have regarding course fee structures, hostels, or syllabus..."
                ></textarea>
              </div>
            </div>

            {/* Submission buttons */}
            <div className="pt-6 border-t border-slate-100 flex items-center justify-end space-x-3">
              <button
                type="button"
                onClick={() => navigate('/dashboard')}
                className="px-5 py-2.5 border border-slate-200 hover:bg-slate-50 text-slate-600 font-semibold rounded-xl text-sm transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={submitting}
                className="px-6 py-2.5 bg-teal-500 hover:bg-teal-400 disabled:bg-teal-300 text-slate-950 font-bold rounded-xl text-sm shadow-sm transition-colors flex items-center space-x-1.5"
              >
                {submitting ? (
                  <div className="w-5 h-5 border-2 border-slate-950 border-t-transparent rounded-full animate-spin"></div>
                ) : (
                  <>
                    <Save className="w-4 h-4" />
                    <span>Submit Enquiry</span>
                  </>
                )}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
