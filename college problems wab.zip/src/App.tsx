import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import ProtectedRoute from './components/ProtectedRoute';
import Navbar from './components/Navbar';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import ProfileSetup from './pages/ProfileSetup';
import AdmissionEnquiryForm from './pages/AdmissionEnquiryForm';
import ScholarshipForm from './pages/ScholarshipForm';
import StaffDashboard from './pages/StaffDashboard';

// Root redirect helper based on role
function RootRedirect() {
  const { user, profile, loading } = useAuth();

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-slate-50 text-slate-600">
        <div className="w-12 h-12 border-4 border-teal-600 border-t-transparent rounded-full animate-spin mb-4"></div>
        <p className="font-medium animate-pulse">Loading portal...</p>
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  if (profile?.role === 'staff') {
    return <Navigate to="/staff-dashboard" replace />;
  }

  return <Navigate to="/dashboard" replace />;
}

function AppContent() {
  const { user } = useAuth();

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      {user && <Navbar />}
      <main className="flex-1">
        <Routes>
          <Route path="/login" element={<Login />} />
          
          {/* Student Protected Routes */}
          <Route path="/dashboard" element={
            <ProtectedRoute>
              <Dashboard />
            </ProtectedRoute>
          } />
          
          <Route path="/profile-setup" element={
            <ProtectedRoute>
              <ProfileSetup />
            </ProtectedRoute>
          } />

          <Route path="/form/admission-enquiry" element={
            <ProtectedRoute>
              <AdmissionEnquiryForm />
            </ProtectedRoute>
          } />

          <Route path="/form/scholarship-application" element={
            <ProtectedRoute>
              <ScholarshipForm />
            </ProtectedRoute>
          } />

          {/* Staff Protected Routes */}
          <Route path="/staff-dashboard" element={
            <ProtectedRoute requireStaff={true}>
              <StaffDashboard />
            </ProtectedRoute>
          } />

          {/* Fallback / Root Redirect */}
          <Route path="/" element={<RootRedirect />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <AppContent />
      </BrowserRouter>
    </AuthProvider>
  );
}
