import supabase from '../db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(204).end();

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { action, phone, otp } = req.body;

    if (!phone) {
      return res.status(400).json({ error: 'Phone number is required' });
    }

    // Standardize phone number (remove spaces, etc.)
    const cleanPhone = phone.trim().replace(/\s+/g, '');

    // Action 1: Send/Generate OTP
    if (action === 'send-otp') {
      // Generate a 6-digit random code
      const generatedOtp = Math.floor(100000 + Math.random() * 900000).toString();
      const expiresAt = new Date(Date.now() + 5 * 60 * 1000).toISOString(); // 5 minutes

      const { error } = await supabase
        .from('phone_otps')
        .upsert({
          phone: cleanPhone,
          otp: generatedOtp,
          expires_at: expiresAt
        });

      if (error) throw error;

      return res.status(200).json({
        success: true,
        message: `OTP generated successfully!`,
        // In a real app we wouldn't return the OTP in the response,
        // but for testing/demo we return it so the user can easily copy/paste.
        otp: generatedOtp
      });
    }

    // Action 2: Verify OTP
    if (action === 'verify-otp') {
      if (!otp) {
        return res.status(400).json({ error: 'OTP code is required' });
      }

      // Fetch OTP from DB
      const { data, error } = await supabase
        .from('phone_otps')
        .select('*')
        .eq('phone', cleanPhone)
        .maybeSingle();

      if (error) throw error;

      if (!data) {
        return res.status(400).json({ error: 'No OTP requested for this phone number' });
      }

      // Check expiry
      if (new Date(data.expires_at) < new Date()) {
        await supabase.from('phone_otps').delete().eq('phone', cleanPhone);
        return res.status(400).json({ error: 'OTP has expired. Please request a new one.' });
      }

      // Verify OTP match
      if (data.otp !== otp.trim()) {
        return res.status(400).json({ error: 'Invalid OTP code. Please try again.' });
      }

      // OTP matches! Delete it so it cannot be reused
      await supabase.from('phone_otps').delete().eq('phone', cleanPhone);

      // Check if profile exists for this phone
      let { data: profile, error: profileError } = await supabase
        .from('profiles')
        .select('*')
        .eq('phone', cleanPhone)
        .maybeSingle();

      if (profileError) throw profileError;

      let isNewUser = false;
      if (!profile) {
        isNewUser = true;
        // Create a new profile with a custom unique ID
        const customId = `phone-user-${Math.random().toString(36).substring(2, 11)}`;
        const { data: newProfile, error: createError } = await supabase
          .from('profiles')
          .insert({
            id: customId,
            phone: cleanPhone,
            role: 'student',
            full_name: 'New Student',
            updated_at: new Date().toISOString()
          })
          .select()
          .single();

        if (createError) throw createError;
        profile = newProfile;
      }

      return res.status(200).json({
        success: true,
        user: {
          id: profile.id,
          phone: profile.phone,
          email: profile.email || '',
          role: profile.role || 'student',
          full_name: profile.full_name || 'New Student'
        },
        isNewUser
      });
    }

    return res.status(400).json({ error: 'Invalid action' });
  } catch (err) {
    console.error('Phone OTP Error:', err);
    return res.status(500).json({ error: err.message });
  }
}
