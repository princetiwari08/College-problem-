import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-User-Id');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    // 1. Resolve User ID
    let userId = req.headers['x-user-id'];
    const authHeader = req.headers.authorization;

    if (authHeader && authHeader.startsWith('Bearer ')) {
      const token = authHeader.substring(7);
      const { data: { user }, error: authError } = await supabase.auth.getUser(token);
      if (!authError && user) {
        userId = user.id;
      }
    }

    if (!userId) {
      return res.status(401).json({ error: 'Unauthorized: User session not found' });
    }

    // 2. GET Profile
    if (req.method === 'GET') {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .maybeSingle();

      if (error) throw error;
      return res.status(200).json(data || null);
    }

    // 3. POST / PUT Profile (Upsert)
    if (req.method === 'POST' || req.method === 'PUT') {
      const {
        email,
        full_name,
        dob,
        gender,
        address,
        phone,
        id_number,
        course_of_interest,
        last_school,
        marks_percentage,
        accessCode
      } = req.body;

      // Determine Role
      let role = 'student';
      if (accessCode === 'STAFF2025') {
        role = 'staff';
      } else {
        // Keep existing role if profile exists
        const { data: existing } = await supabase
          .from('profiles')
          .select('role')
          .eq('id', userId)
          .maybeSingle();
        if (existing?.role) {
          role = existing.role;
        }
      }

      const profileData = {
        id: userId,
        email: email || '',
        full_name: full_name || '',
        dob: dob || '',
        gender: gender || '',
        address: address || '',
        phone: phone || '',
        id_number: id_number || '',
        course_of_interest: course_of_interest || '',
        last_school: last_school || '',
        marks_percentage: marks_percentage ? parseFloat(marks_percentage) : null,
        role,
        updated_at: new Date().toISOString()
      };

      const { data, error } = await supabase
        .from('profiles')
        .upsert(profileData)
        .select()
        .single();

      if (error) throw error;
      return res.status(200).json(data);
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Profile API Error:', err);
    return res.status(500).json({ error: err.message });
  }
}
