import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-User-Id');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    // 1. Resolve User ID and Role
    let userId = req.headers['x-user-id'];
    let userEmail = '';
    const authHeader = req.headers.authorization;

    if (authHeader && authHeader.startsWith('Bearer ')) {
      const token = authHeader.substring(7);
      const { data: { user }, error: authError } = await supabase.auth.getUser(token);
      if (!authError && user) {
        userId = user.id;
        userEmail = user.email || '';
      }
    }

    if (!userId) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    // Fetch profile to verify role
    const { data: profile } = await supabase
      .from('profiles')
      .select('role, email')
      .eq('id', userId)
      .maybeSingle();

    const isStaff = profile?.role === 'staff';
    const emailToUse = userEmail || profile?.email || '';

    // 2. GET Submissions
    if (req.method === 'GET') {
      let query = supabase.from('form_submissions').select('*');

      if (isStaff) {
        // Staff can see all submissions, support query-based filters
        const { search, status, form_type } = req.query;
        if (status) {
          query = query.eq('status', status);
        }
        if (form_type) {
          query = query.eq('form_type', form_type);
        }
        if (search) {
          query = query.or(`full_name.ilike.%${search}%,email.ilike.%${search}%,id_number.ilike.%${search}%`);
        }
      } else {
        // Students can only see their own submissions
        query = query.eq('user_id', userId);
      }

      const { data, error } = await query.order('created_at', { ascending: false });
      if (error) throw error;
      return res.status(200).json(data);
    }

    // 3. POST New Submission
    if (req.method === 'POST') {
      const {
        form_type,
        full_name,
        dob,
        gender,
        address,
        phone,
        email,
        id_number,
        course_of_interest,
        last_school,
        marks_percentage,
        additional_details
      } = req.body;

      if (!form_type || !full_name) {
        return res.status(400).json({ error: 'Missing required fields' });
      }

      const submissionData = {
        user_id: userId,
        form_type,
        full_name,
        dob,
        gender,
        address,
        phone,
        email: email || emailToUse,
        id_number,
        course_of_interest,
        last_school,
        marks_percentage: marks_percentage ? parseFloat(marks_percentage) : null,
        additional_details: additional_details || {},
        status: 'pending',
        created_at: new Date().toISOString()
      };

      const { data, error } = await supabase
        .from('form_submissions')
        .insert(submissionData)
        .select()
        .single();

      if (error) throw error;
      return res.status(201).json(data);
    }

    // 4. PUT Update Submission Status (Staff Only)
    if (req.method === 'PUT') {
      if (!isStaff) {
        return res.status(403).json({ error: 'Forbidden: Staff access required' });
      }

      const { id, status } = req.body;
      if (!id || !status) {
        return res.status(400).json({ error: 'Missing id or status' });
      }

      const { data, error } = await supabase
        .from('form_submissions')
        .update({ status })
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return res.status(200).json(data);
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Submissions API Error:', err);
    return res.status(500).json({ error: err.message });
  }
}
